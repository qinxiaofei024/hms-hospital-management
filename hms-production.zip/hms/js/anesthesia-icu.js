// 麻醉重症运营分析页面JavaScript
var AnesthesiaICUPage = {
    // 初始化页面
    init: function() {
        this.initEventListeners();
        this.loadData();
        this.initCharts();
    },
    
    // 初始化事件监听器
    initEventListeners: function() {
        // 刷新按钮点击事件
        document.getElementById('refresh-btn').addEventListener('click', function() {
            AnesthesiaICUPage.refreshData();
        });
        
        // 导出报表按钮点击事件
        document.getElementById('export-btn').addEventListener('click', function() {
            AnesthesiaICUPage.exportReport();
        });
        
        // 时间范围选择事件
        document.getElementById('time-range').addEventListener('change', function() {
            AnesthesiaICUPage.loadData();
        });
        
        // 科室选择事件
        document.getElementById('department').addEventListener('change', function() {
            AnesthesiaICUPage.loadData();
        });
    },
    
    // 加载数据
    loadData: function() {
        var timeRange = document.getElementById('time-range').value;
        var department = document.getElementById('department').value;
        
        // 获取模拟数据
        var data = this.getMockData(timeRange, department);
        
        // 更新概览卡片数据
        this.updateOverviewCards(data.overview);
        
        // 更新详细数据表格
        this.updateDataTable(data.detailData);
        
        // 更新图表数据
        this.updateCharts(data.charts);
        
        // 更新KPI数据
        this.updateKPI(data.kpi);
    },
    
    // 获取模拟数据
    getMockData: function(timeRange, department) {
        // 根据不同的时间范围和科室返回不同的模拟数据
        // 这里返回的是默认的模拟数据
        return {
            overview: {
                anesthesiaCases: 1256,
                icuAdmissions: 328,
                totalRevenue: 295.0,
                avgStayDays: 7.2,
                trends: {
                    anesthesiaCases: 5.2,
                    icuAdmissions: 3.8,
                    totalRevenue: 8.7,
                    avgStayDays: -0.8
                }
            },
            charts: {
                anesthesiaTrend: {
                    months: ['1月', '2月', '3月', '4月', '5月', '6月'],
                    cases: [980, 1025, 1150, 1180, 1220, 1256]
                },
                icuTrend: {
                    months: ['1月', '2月', '3月', '4月', '5月', '6月'],
                    admissions: [265, 280, 302, 310, 318, 328]
                },
                revenueComposition: {
                    categories: ['麻醉收入', 'ICU收入'],
                    values: [163.8, 131.2]
                },
                surgeryType: {
                    categories: ['普外科手术', '骨科手术', '神经外科手术', '心脏外科手术', '妇产科手术', '其他手术'],
                    values: [28, 22, 18, 15, 10, 7]
                }
            },
            kpi: [
                { name: '麻醉成功率', value: 99.8, target: 99.5, status: 'good' },
                { name: 'ICU床位使用率', value: 86.5, target: 85, status: 'good' },
                { name: '麻醉并发症率', value: 0.2, target: 0.5, status: 'good' },
                { name: 'ICU死亡率', value: 4.8, target: 8, status: 'good' }
            ],
            detailData: [
                { month: '1月', anesthesiaCases: 980, icuAdmissions: 265, anesthesiaRevenue: 125.6, icuRevenue: 98.3, totalRevenue: 223.9, growthRate: '--' },
                { month: '2月', anesthesiaCases: 1025, icuAdmissions: 280, anesthesiaRevenue: 132.8, icuRevenue: 105.6, totalRevenue: 238.4, growthRate: '+6.5%' },
                { month: '3月', anesthesiaCases: 1150, icuAdmissions: 302, anesthesiaRevenue: 148.2, icuRevenue: 118.5, totalRevenue: 266.7, growthRate: '+11.9%' },
                { month: '4月', anesthesiaCases: 1180, icuAdmissions: 310, anesthesiaRevenue: 152.5, icuRevenue: 122.3, totalRevenue: 274.8, growthRate: '+3.0%' },
                { month: '5月', anesthesiaCases: 1220, icuAdmissions: 318, anesthesiaRevenue: 158.6, icuRevenue: 126.4, totalRevenue: 285.0, growthRate: '+3.7%' },
                { month: '6月', anesthesiaCases: 1256, icuAdmissions: 328, anesthesiaRevenue: 163.8, icuRevenue: 131.2, totalRevenue: 295.0, growthRate: '+3.5%' }
            ]
        };
    },
    
    // 初始化图表
    initCharts: function() {
        // 麻醉例数趋势图
        this.anesthesiaTrendChart = echarts.init(document.getElementById('anesthesia-trend-chart'));
        // ICU入住趋势图
        this.icuTrendChart = echarts.init(document.getElementById('icu-trend-chart'));
        // 收入构成分析图
        this.revenueCompositionChart = echarts.init(document.getElementById('revenue-composition-chart'));
        // 手术类型分布图
        this.surgeryTypeChart = echarts.init(document.getElementById('surgery-type-chart'));
        
        // 设置默认图表配置
        this.updateCharts(this.getMockData('month', 'all').charts);
        
        // 窗口大小改变时重新调整图表大小
        window.addEventListener('resize', function() {
            AnesthesiaICUPage.anesthesiaTrendChart.resize();
            AnesthesiaICUPage.icuTrendChart.resize();
            AnesthesiaICUPage.revenueCompositionChart.resize();
            AnesthesiaICUPage.surgeryTypeChart.resize();
        });
    },
    
    // 更新图表数据
    updateCharts: function(chartsData) {
        // 更新麻醉例数趋势图
        var anesthesiaTrendOption = {
            tooltip: {
                trigger: 'axis',
                formatter: '{b}: {c}例'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: chartsData.anesthesiaTrend.months
            },
            yAxis: {
                type: 'value',
                axisLabel: {
                    formatter: '{value}例'
                }
            },
            series: [{
                name: '麻醉例数',
                type: 'line',
                data: chartsData.anesthesiaTrend.cases,
                smooth: true,
                lineStyle: {
                    color: '#0066cc',
                    width: 3
                },
                itemStyle: {
                    color: '#0066cc'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(0, 102, 204, 0.3)'
                    }, {
                        offset: 1,
                        color: 'rgba(0, 102, 204, 0.05)'
                    }])
                }
            }]
        };
        this.anesthesiaTrendChart.setOption(anesthesiaTrendOption);
        
        // 更新ICU入住趋势图
        var icuTrendOption = {
            tooltip: {
                trigger: 'axis',
                formatter: '{b}: {c}人次'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: chartsData.icuTrend.months
            },
            yAxis: {
                type: 'value',
                axisLabel: {
                    formatter: '{value}人次'
                }
            },
            series: [{
                name: 'ICU入住人次',
                type: 'line',
                data: chartsData.icuTrend.admissions,
                smooth: true,
                lineStyle: {
                    color: '#52c41a',
                    width: 3
                },
                itemStyle: {
                    color: '#52c41a'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(82, 196, 26, 0.3)'
                    }, {
                        offset: 1,
                        color: 'rgba(82, 196, 26, 0.05)'
                    }])
                }
            }]
        };
        this.icuTrendChart.setOption(icuTrendOption);
        
        // 更新收入构成分析图
        var revenueCompositionOption = {
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b}: {c}万元 ({d}%)'
            },
            legend: {
                orient: 'vertical',
                left: 10,
                data: chartsData.revenueComposition.categories
            },
            series: [{
                name: '收入构成',
                type: 'pie',
                radius: '55%',
                center: ['50%', '60%'],
                data: chartsData.revenueComposition.categories.map((category, index) => ({
                    value: chartsData.revenueComposition.values[index],
                    name: category
                })),
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
                itemStyle: {
                    color: function(params) {
                        var colorList = ['#0066cc', '#52c41a'];
                        return colorList[params.dataIndex];
                    }
                },
                label: {
                    formatter: '{b}: {c}万元'
                }
            }]
        };
        this.revenueCompositionChart.setOption(revenueCompositionOption);
        
        // 更新手术类型分布图
        var surgeryTypeOption = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                },
                formatter: '{b}: {c}%'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                axisLabel: {
                    formatter: '{value}%'
                }
            },
            yAxis: {
                type: 'category',
                data: chartsData.surgeryType.categories
            },
            series: [{
                name: '手术类型占比',
                type: 'bar',
                data: chartsData.surgeryType.values,
                itemStyle: {
                    color: function(params) {
                        var colorList = ['#0066cc', '#52c41a', '#faad14', '#ff4d4f', '#722ed1', '#eb2f96'];
                        return colorList[params.dataIndex];
                    }
                },
                label: {
                    show: true,
                    position: 'right',
                    formatter: '{c}%'
                }
            }]
        };
        this.surgeryTypeChart.setOption(surgeryTypeOption);
    },
    
    // 更新概览卡片
    updateOverviewCards: function(overviewData) {
        var cards = document.querySelectorAll('.overview-card');
        
        // 麻醉总例数卡片
        cards[0].querySelector('.card-value').textContent = overviewData.anesthesiaCases.toLocaleString();
        var trendEl = cards[0].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.anesthesiaCases > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.anesthesiaCases > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.anesthesiaCases > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.anesthesiaCases) + '%';
        
        // ICU入住人次卡片
        cards[1].querySelector('.card-value').textContent = overviewData.icuAdmissions.toLocaleString();
        trendEl = cards[1].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.icuAdmissions > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.icuAdmissions > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.icuAdmissions > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.icuAdmissions) + '%';
        
        // 总收入卡片
        cards[2].querySelector('.card-value').textContent = '¥' + overviewData.totalRevenue.toFixed(1) + '万';
        trendEl = cards[2].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.totalRevenue > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.totalRevenue > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.totalRevenue > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.totalRevenue) + '%';
        
        // 平均住院日卡片
        cards[3].querySelector('.card-value').textContent = overviewData.avgStayDays + '天';
        trendEl = cards[3].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.avgStayDays < 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.avgStayDays < 0 ? 'down' : 'up') + '"></i> 较上月' + (overviewData.trends.avgStayDays < 0 ? '下降' : '增长') + ' ' + Math.abs(overviewData.trends.avgStayDays) + '天';
    },
    
    // 更新详细数据表格
    updateDataTable: function(detailData) {
        var tbody = document.querySelector('.data-table tbody');
        tbody.innerHTML = '';
        
        detailData.forEach(function(item) {
            var tr = document.createElement('tr');
            tr.innerHTML = '
                <td>' + item.month + '</td>
                <td>' + item.anesthesiaCases.toLocaleString() + '</td>
                <td>' + item.icuAdmissions.toLocaleString() + '</td>
                <td>' + item.anesthesiaRevenue + '</td>
                <td>' + item.icuRevenue + '</td>
                <td>' + item.totalRevenue + '</td>
                <td class="' + (item.growthRate !== '--' && item.growthRate.includes('+') ? 'trend-up' : (item.growthRate !== '--' ? 'trend-down' : '')) + '">' + item.growthRate + '</td>
            ';
            tbody.appendChild(tr);
        });
    },
    
    // 更新KPI数据
    updateKPI: function(kpiData) {
        var kpiCards = document.querySelectorAll('.kpi-card');
        
        kpiData.forEach(function(kpi, index) {
            if (kpiCards[index]) {
                kpiCards[index].querySelector('.kpi-title').textContent = kpi.name;
                kpiCards[index].querySelector('.kpi-value').textContent = kpi.value + (kpi.name.includes('率') ? '%' : '');
                kpiCards[index].querySelector('.kpi-target').textContent = '目标: ' + (kpi.name.includes('率') ? '' : '') + kpi.target + (kpi.name.includes('率') ? '%' : '');
                
                var progressFill = kpiCards[index].querySelector('.progress-fill');
                progressFill.style.width = (kpi.name.includes('并发症') || kpi.name.includes('死亡') ? (kpi.value / kpi.target * 100) : kpi.value) + '%';
                
                // 移除所有进度状态类
                progressFill.classList.remove('progress-good', 'progress-warning', 'progress-danger');
                
                // 添加相应的进度状态类
                if (kpi.status === 'good') {
                    progressFill.classList.add('progress-good');
                } else if (kpi.status === 'warning') {
                    progressFill.classList.add('progress-warning');
                } else {
                    progressFill.classList.add('progress-danger');
                }
            }
        });
    },
    
    // 刷新数据
    refreshData: function() {
        // 显示加载动画
        var refreshBtn = document.getElementById('refresh-btn');
        var originalText = refreshBtn.textContent;
        refreshBtn.innerHTML = '<i class="icon-refresh"></i> 刷新中...';
        refreshBtn.disabled = true;
        
        // 模拟网络请求延迟
        setTimeout(function() {
            AnesthesiaICUPage.loadData();
            
            // 恢复按钮状态
            refreshBtn.textContent = originalText;
            refreshBtn.disabled = false;
        }, 1000);
    },
    
    // 导出报表
    exportReport: function() {
        // 显示导出提示
        alert('报表导出成功！');
        
        // 实际项目中这里应该调用后端接口导出报表
        console.log('导出麻醉重症运营分析报表');
    }
};

// 页面加载完成后初始化
window.addEventListener('load', function() {
    AnesthesiaICUPage.init();
});