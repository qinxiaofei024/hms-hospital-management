// 超声医学运营分析页面JavaScript
var UltrasoundPage = {
    // 初始化页面
    init: function() {
        this.initEventListeners();
        this.loadData();
        this.initCharts();
    },
    
    // 初始化事件监听器
    initEventListeners: function() {
        // 刷新按钮点击事件
        document.getElementById('refresh-btn').addEventListener('click', function() {
            UltrasoundPage.refreshData();
        });
        
        // 导出报表按钮点击事件
        document.getElementById('export-btn').addEventListener('click', function() {
            UltrasoundPage.exportReport();
        });
        
        // 时间范围选择事件
        document.getElementById('time-range').addEventListener('change', function() {
            UltrasoundPage.loadData();
        });
        
        // 科室选择事件
        document.getElementById('department').addEventListener('change', function() {
            UltrasoundPage.loadData();
        });
    },
    
    // 加载数据
    loadData: function() {
        var timeRange = document.getElementById('time-range').value;
        var department = document.getElementById('department').value;
        
        // 获取模拟数据
        var data = this.getMockData(timeRange, department);
        
        // 更新概览卡片数据
        this.updateOverviewCards(data.overview);
        
        // 更新设备状态卡片
        this.updateEquipmentStatus(data.equipment);
        
        // 更新详细数据表格
        this.updateDataTable(data.detailData);
        
        // 更新图表数据
        this.updateCharts(data.charts);
    },
    
    // 获取模拟数据
    getMockData: function(timeRange, department) {
        // 根据不同的时间范围和科室返回不同的模拟数据
        // 这里返回的是默认的模拟数据
        return {
            overview: {
                totalExaminations: 5862,
                totalRevenue: 128.5,
                avgEquipmentUsage: 78.5,
                positiveRate: 38.2,
                trends: {
                    totalExaminations: 4.3,
                    totalRevenue: 6.8,
                    avgEquipmentUsage: 2.1,
                    positiveRate: -0.5
                }
            },
            equipment: [
                { name: '高端彩超仪A', usage: 85.2, status: 'normal' },
                { name: '高端彩超仪B', usage: 81.6, status: 'normal' },
                { name: '中端彩超仪C', usage: 76.3, status: 'normal' },
                { name: '便携彩超仪D', usage: 68.9, status: 'warning' }
            ],
            charts: {
                examinationTrend: {
                    months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月'],
                    count: [4180, 4390, 4770, 5020, 5260, 5440, 5660, 5922]
                },
                examinationType: {
                    categories: ['腹部超声', '心脏超声', '血管超声', '妇产科超声', '肌肉骨骼超声'],
                    values: [1750, 1250, 960, 1350, 612]
                },
                revenueTrend: {
                    months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月'],
                    revenue: [89.6, 95.2, 103.5, 108.7, 114.3, 119.8, 124.7, 131.2]
                },
                equipmentUsage: {
                    names: ['高端彩超仪A', '高端彩超仪B', '中端彩超仪C', '便携彩超仪D'],
                    usage: [85.2, 81.6, 76.3, 68.9]
                }
            },
            detailData: [
                { month: '1月', abdominal: 1250, cardiac: 850, vascular: 680, obstetric: 980, musculoskeletal: 420, totalExaminations: 4180, totalRevenue: 89.6 },
                { month: '2月', abdominal: 1320, cardiac: 890, vascular: 710, obstetric: 1020, musculoskeletal: 450, totalExaminations: 4390, totalRevenue: 95.2 },
                { month: '3月', abdominal: 1450, cardiac: 960, vascular: 780, obstetric: 1100, musculoskeletal: 480, totalExaminations: 4770, totalRevenue: 103.5 },
                { month: '4月', abdominal: 1520, cardiac: 1020, vascular: 820, obstetric: 1150, musculoskeletal: 510, totalExaminations: 5020, totalRevenue: 108.7 },
                { month: '5月', abdominal: 1580, cardiac: 1080, vascular: 860, obstetric: 1200, musculoskeletal: 540, totalExaminations: 5260, totalRevenue: 114.3 },
                { month: '6月', abdominal: 1620, cardiac: 1120, vascular: 890, obstetric: 1250, musculoskeletal: 560, totalExaminations: 5440, totalRevenue: 119.8 },
                { month: '7月', abdominal: 1680, cardiac: 1180, vascular: 920, obstetric: 1300, musculoskeletal: 580, totalExaminations: 5660, totalRevenue: 124.7 },
                { month: '8月', abdominal: 1750, cardiac: 1250, vascular: 960, obstetric: 1350, musculoskeletal: 612, totalExaminations: 5922, totalRevenue: 131.2 }
            ]
        };
    },
    
    // 初始化图表
    initCharts: function() {
        // 检查量趋势图
        this.examinationTrendChart = echarts.init(document.getElementById('examination-trend-chart'));
        // 检查类型分布图
        this.examinationTypeChart = echarts.init(document.getElementById('examination-type-chart'));
        // 收入趋势分析图
        this.revenueTrendChart = echarts.init(document.getElementById('revenue-trend-chart'));
        // 设备使用率对比图
        this.equipmentUsageChart = echarts.init(document.getElementById('equipment-usage-chart'));
        
        // 设置默认图表配置
        this.updateCharts(this.getMockData('month', 'all').charts);
        
        // 窗口大小改变时重新调整图表大小
        window.addEventListener('resize', function() {
            UltrasoundPage.examinationTrendChart.resize();
            UltrasoundPage.examinationTypeChart.resize();
            UltrasoundPage.revenueTrendChart.resize();
            UltrasoundPage.equipmentUsageChart.resize();
        });
    },
    
    // 更新图表数据
    updateCharts: function(chartsData) {
        // 更新检查量趋势图
        var examinationTrendOption = {
            tooltip: {
                trigger: 'axis',
                formatter: '{b}: {c}人次'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: chartsData.examinationTrend.months
            },
            yAxis: {
                type: 'value',
                axisLabel: {
                    formatter: '{value}人次'
                }
            },
            series: [{
                name: '检查量',
                type: 'line',
                data: chartsData.examinationTrend.count,
                smooth: true,
                lineStyle: {
                    color: '#0066cc',
                    width: 3
                },
                itemStyle: {
                    color: '#0066cc'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(0, 102, 204, 0.3)'
                    }, {
                        offset: 1,
                        color: 'rgba(0, 102, 204, 0.05)'
                    }])
                }
            }]
        };
        this.examinationTrendChart.setOption(examinationTrendOption);
        
        // 更新检查类型分布图
        var examinationTypeOption = {
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b}: {c}人次 ({d}%)'
            },
            legend: {
                orient: 'vertical',
                left: 10,
                data: chartsData.examinationType.categories
            },
            series: [{
                name: '检查类型',
                type: 'pie',
                radius: '55%',
                center: ['50%', '60%'],
                data: chartsData.examinationType.categories.map((category, index) => ({
                    value: chartsData.examinationType.values[index],
                    name: category
                })),
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
                itemStyle: {
                    color: function(params) {
                        var colorList = ['#0066cc', '#52c41a', '#faad14', '#ff4d4f', '#722ed1'];
                        return colorList[params.dataIndex];
                    }
                },
                label: {
                    formatter: '{b}: {c}人次'
                }
            }]
        };
        this.examinationTypeChart.setOption(examinationTypeOption);
        
        // 更新收入趋势分析图
        var revenueTrendOption = {
            tooltip: {
                trigger: 'axis',
                formatter: '{b}: {c}万元'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: chartsData.revenueTrend.months
            },
            yAxis: {
                type: 'value',
                axisLabel: {
                    formatter: '{value}万元'
                }
            },
            series: [{
                name: '收入',
                type: 'line',
                data: chartsData.revenueTrend.revenue,
                smooth: true,
                lineStyle: {
                    color: '#52c41a',
                    width: 3
                },
                itemStyle: {
                    color: '#52c41a'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(82, 196, 26, 0.3)'
                    }, {
                        offset: 1,
                        color: 'rgba(82, 196, 26, 0.05)'
                    }])
                }
            }]
        };
        this.revenueTrendChart.setOption(revenueTrendOption);
        
        // 更新设备使用率对比图
        var equipmentUsageOption = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                },
                formatter: '{b}: {c}%'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                axisLabel: {
                    formatter: '{value}%'
                },
                max: 100
            },
            yAxis: {
                type: 'category',
                data: chartsData.equipmentUsage.names
            },
            series: [{
                name: '设备使用率',
                type: 'bar',
                data: chartsData.equipmentUsage.usage,
                itemStyle: {
                    color: function(params) {
                        if (params.data >= 80) {
                            return '#0066cc';
                        } else if (params.data >= 70) {
                            return '#52c41a';
                        } else {
                            return '#faad14';
                        }
                    }
                },
                label: {
                    show: true,
                    position: 'right',
                    formatter: '{c}%'
                }
            }]
        };
        this.equipmentUsageChart.setOption(equipmentUsageOption);
    },
    
    // 更新概览卡片
    updateOverviewCards: function(overviewData) {
        var cards = document.querySelectorAll('.overview-card');
        
        // 总检查人次卡片
        cards[0].querySelector('.card-value').textContent = overviewData.totalExaminations.toLocaleString();
        var trendEl = cards[0].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.totalExaminations > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.totalExaminations > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.totalExaminations > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.totalExaminations) + '%';
        
        // 总收入卡片
        cards[1].querySelector('.card-value').textContent = '¥' + overviewData.totalRevenue.toFixed(1) + '万';
        trendEl = cards[1].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.totalRevenue > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.totalRevenue > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.totalRevenue > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.totalRevenue) + '%';
        
        // 平均设备使用率卡片
        cards[2].querySelector('.card-value').textContent = overviewData.avgEquipmentUsage + '%';
        trendEl = cards[2].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.avgEquipmentUsage > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.avgEquipmentUsage > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.avgEquipmentUsage > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.avgEquipmentUsage) + '%';
        
        // 阳性检出率卡片
        cards[3].querySelector('.card-value').textContent = overviewData.positiveRate + '%';
        trendEl = cards[3].querySelector('.card-trend');
        trendEl.className = 'card-trend ' + (overviewData.trends.positiveRate > 0 ? 'trend-up' : 'trend-down');
        trendEl.innerHTML = '<i class="icon-arrow-' + (overviewData.trends.positiveRate > 0 ? 'up' : 'down') + '"></i> 较上月' + (overviewData.trends.positiveRate > 0 ? '增长' : '下降') + ' ' + Math.abs(overviewData.trends.positiveRate) + '%';
    },
    
    // 更新设备状态卡片
    updateEquipmentStatus: function(equipmentData) {
        var equipmentCards = document.querySelectorAll('.equipment-card');
        
        equipmentData.forEach(function(equipment, index) {
            if (equipmentCards[index]) {
                equipmentCards[index].querySelector('.equipment-name').textContent = equipment.name;
                equipmentCards[index].querySelector('.equipment-usage').textContent = equipment.usage + '%';
                
                var statusEl = equipmentCards[index].querySelector('.equipment-status-text');
                statusEl.className = 'equipment-status-text status-' + equipment.status;
                
                if (equipment.status === 'normal') {
                    statusEl.textContent = '正常运行';
                } else if (equipment.status === 'warning') {
                    statusEl.textContent = '使用率偏低';
                } else {
                    statusEl.textContent = '需要维护';
                }
            }
        });
    },
    
    // 更新详细数据表格
    updateDataTable: function(detailData) {
        var tbody = document.querySelector('.data-table tbody');
        tbody.innerHTML = '';
        
        detailData.forEach(function(item) {
            var tr = document.createElement('tr');
            tr.innerHTML = '
                <td>' + item.month + '</td>
                <td>' + item.abdominal.toLocaleString() + '</td>
                <td>' + item.cardiac.toLocaleString() + '</td>
                <td>' + item.vascular.toLocaleString() + '</td>
                <td>' + item.obstetric.toLocaleString() + '</td>
                <td>' + item.musculoskeletal.toLocaleString() + '</td>
                <td>' + item.totalExaminations.toLocaleString() + '</td>
                <td>' + item.totalRevenue + '</td>
            ';
            tbody.appendChild(tr);
        });
    },
    
    // 刷新数据
    refreshData: function() {
        // 显示加载动画
        var refreshBtn = document.getElementById('refresh-btn');
        var originalText = refreshBtn.textContent;
        refreshBtn.innerHTML = '<i class="icon-refresh"></i> 刷新中...';
        refreshBtn.disabled = true;
        
        // 模拟网络请求延迟
        setTimeout(function() {
            UltrasoundPage.loadData();
            
            // 恢复按钮状态
            refreshBtn.textContent = originalText;
            refreshBtn.disabled = false;
        }, 1000);
    },
    
    // 导出报表
    exportReport: function() {
        // 显示导出提示
        alert('报表导出成功！');
        
        // 实际项目中这里应该调用后端接口导出报表
        console.log('导出超声医学运营分析报表');
    }
};

// 页面加载完成后初始化
window.addEventListener('load', function() {
    UltrasoundPage.init();
});